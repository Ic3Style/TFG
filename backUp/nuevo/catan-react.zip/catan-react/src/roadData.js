//TIENE LOS DATOS DE TODAS LAS CARRETERAS
export const roadData = [
    
         {
            "id": 0,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 3,
            "to": 0
          }
    ,
    
         {
            "id": 1,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 0,
            "to": 4
          }
    ,
    
         {
            "id": 2,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 4,
            "to": 1
          }
    ,
    
         {
            "id": 3,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 1,
            "to": 5
          }
    ,
    
         {
            "id": 4,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 5,
            "to": 2
          }
    ,
    
         {
            "id": 5,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 2,
            "to": 6
          }
    ,
    
         {
            "id": 6,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 3,
            "to": 7
          }
    ,
    
         {
            "id": 7,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 4,
            "to": 8
          }
    ,
    
         {
            "id": 8,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 5,
            "to": 9
          }
    ,
    
         {
            "id": 9,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 6,
            "to": 10
          }
    ,
    
         {
            "id": 10,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 11,
            "to": 7
          }
    ,
    
         {
            "id": 11,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 7,
            "to": 12
          }
    ,
    
         {
            "id": 12,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 12,
            "to": 8
          }
    ,
    
         {
            "id": 13,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 8,
            "to": 13
          }
    ,
    
         {
            "id": 14,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 13,
            "to": 9
          }
    ,
    
         {
            "id": 15,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 9,
            "to": 14
          }
    ,
    
         {
            "id": 16,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 14,
            "to": 10
          }
    ,
    
         {
            "id": 17,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 10,
            "to": 15
          }
    ,
    
         {
            "id": 18,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 11,
            "to": 16
          }
    ,
    
         {
            "id": 19,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 12,
            "to": 17
          }
    ,
    
         {
            "id": 20,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 13,
            "to": 18
          }
    ,
    
         {
            "id": 21,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 14,
            "to": 19
          }
    ,
    
         {
            "id": 22,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 15,
            "to": 20
          }
    ,
    
         {
            "id": 23,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 21,
            "to": 16
          }
    ,
    
         {
            "id": 24,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 16,
            "to": 22
          }
    ,
    
         {
            "id": 25,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 22,
            "to": 17
          }
    ,
    
         {
            "id": 26,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 17,
            "to": 23
          }
    ,
    
         {
            "id": 27,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 23,
            "to": 18
          }
    ,
    
         {
            "id": 28,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 18,
            "to": 24
          }
    ,
    
         {
            "id": 29,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 24,
            "to": 19
          }
    ,
    
         {
            "id": 30,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 19,
            "to": 25
          }
    ,
    
         {
            "id": 31,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 25,
            "to": 20
          }
    ,
    
         {
            "id": 32,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 20,
            "to": 26
          }
    ,
    
         {
            "id": 33,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 21,
            "to": 27
          }
    ,
    
         {
            "id": 34,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 22,
            "to": 28
          }
    ,
    
         {
            "id": 35,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 23,
            "to": 29
          }
    ,
    
         {
            "id": 36,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 24,
            "to": 30
          }
    ,
    
         {
            "id": 37,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 25,
            "to": 31
          }
    ,
    
         {
            "id": 38,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 26,
            "to": 32
          }
    ,
    
         {
            "id": 39,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 27,
            "to": 33
          }
    ,
    
         {
            "id": 40,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 33,
            "to": 28
          }
    ,
    
         {
            "id": 41,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 28,
            "to": 34
          }
    ,
   
         {
            "id": 42,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 34,
            "to": 29
          }
    ,
    
         {
            "id": 43,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 29,
            "to": 35
          }
    ,
    
         {
            "id": 44,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 35,
            "to": 30
          }
    ,
    
         {
            "id": 45,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 30,
            "to": 36
          }
    ,
    
         {
            "id": 46,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 36,
            "to": 31
          }
    ,
    
         {
            "id": 47,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 31,
            "to": 37
          }
    ,
    
         {
            "id": 48,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 37,
            "to": 32
          }
    ,
    
         {
            "id": 49,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 33,
            "to": 38
          }
    ,
    
         {
            "id": 50,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 34,
            "to": 39
          }
    ,
    
         {
            "id": 51,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 35,
            "to": 40
          }
    ,
    
         {
            "id": 52,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 36,
            "to": 41
          }
    ,
    
         {
            "id": 53,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 37,
            "to": 42
          }
    ,
    
         {
            "id": 54,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 38,
            "to": 43
          }
    ,
    
         {
            "id": 55,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 43,
            "to": 39
          }
    ,
    
         {
            "id": 56,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 39,
            "to": 44
          }
    ,
    
         {
            "id": 57,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 44,
            "to": 40
          }
    ,
    
         {
            "id": 58,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 40,
            "to": 45
          }
    ,
    
         {
            "id": 59,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 45,
            "to": 41
          }
    ,
    
         {
            "id": 60,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 41,
            "to": 46
          }
    ,
    
         {
            "id": 61,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 46,
            "to": 42
          }
    ,
    
         {
            "id": 62,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 43,
            "to": 47
          }
    ,
    
         {
            "id": 63,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 44,
            "to": 48
          }
    ,
    
         {
            "id": 64,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 45,
            "to": 49
          }
    ,
    
         {
            "id": 65,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 46,
            "to": 50
          }
    ,
    
         {
            "id": 66,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 47,
            "to": 51
          }
    ,
    
         {
            "id": 67,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 51,
            "to": 48
          }
    ,
    
         {
            "id": 68,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 48,
            "to": 52
          }
    ,
    
         {
            "id": 69,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 52,
            "to": 49
          }
    ,
    
         {
            "id": 70,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 49,
            "to": 53
          }
    ,
         {
            "id": 71,
            "value": -1, //"id" del jugador que tenga la carretera
            "from": 53,
            "to": 50
        }

]